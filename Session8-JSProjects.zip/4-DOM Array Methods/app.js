const main = document.getElementById('main')
const addUserBtn = document.getElementById('add-user')
const doubleBtn = document.getElementById('double')
const millBtn = document.getElementById('show-mill')
const sortBtn = document.getElementById('sort')
const calculateBtn = document.getElementById('calculate-wealth')

let data = []
getRandomUser()
getRandomUser()
getRandomUser()
//fetch random user and add money

async function getRandomUser(){
    const res = await fetch('https://randomuser.me/api')
    const data = await res.json()

    const user = data.results[0]

    const newUser = {
        name: `${user.name.first} ${user.name.last}`,
        money: Math.floor(Math.random() * 1000000)
    }
    addData(newUser)
}

//double money function
function doubleMoney(providedData){
    //map() method creates a new array populated with the results of calling a provided function on every element in the calling array.
    data = data.map(user =>{
        return { ...user, money: user.money * 2 }
    })

    updateDom()
}

function sortByRichest(){
    data.sort((a, b) => b.money - a.money)

    updateDom()
}

//filter only millionairs
function showMillionaires(){
    //filter method creates a new array with all the elements that pass the test implemented by the provided funtion
    data = data.filter(user => user.money >= 1000000)
    updateDom()
}

//calculate total wealth
function calculateAllWealth(){
    //The reduce() method executes a reducer function (that you provide) on each element of the array, resulting in single output value.
    const wealth = data.reduce((acc, user) => (acc += user.money), 0)

    const wealthElement = document.createElement('div')
    wealthElement.innerHTML = `<h3>Total Wealth: <strong>${formatMoney(wealth)}</strong></h3>`
    main.appendChild(wealthElement)
}


// add new obj to data array
function addData(obj){
    data.push(obj)

    updateDom()
}

function updateDom(providedData = data){ //if no param is passed in this function, data will be the defualt value
    //clear main div
    main.innerHTML = "<h2><strong>Person</strong>Wealth</h2>"

    // providedData.forEach(function(item){

    // })
    providedData.forEach(item => {
        const element = document.createElement('div')
        element.classList.add('person')
        element.innerHTML = `<strong>${item.name}</strong> ${formatMoney(item.money)}`
        main.appendChild(element)
    })
}

//format number as money
function formatMoney(number){
    return '$'+number.toFixed(1).replace(/\d(?=(\d{3})+\.)/g, '$&,')

}

//event listener
addUserBtn.addEventListener('click',getRandomUser)
doubleBtn.addEventListener('click', doubleMoney)
sortBtn.addEventListener('click', sortByRichest)
millBtn.addEventListener('click', showMillionaires)
calculateBtn.addEventListener('click', calculateAllWealth)